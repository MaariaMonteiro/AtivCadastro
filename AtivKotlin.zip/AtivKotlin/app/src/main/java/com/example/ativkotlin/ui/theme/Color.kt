package com.example.ativkotlin.ui.theme

import androidx.compose.ui.graphics.Color

val Purple500 = Color(0xFF66056E)
val PurpleGrey80 = Color(0xFFBF35C5)
val Pink80 = Color(0xFFBB0034)

val Purple40 = Color(0xFFE72CC0)
val Minhacor = Color(0xFFF35BCE)
val Pink40 = Color(0xFF7D5260)